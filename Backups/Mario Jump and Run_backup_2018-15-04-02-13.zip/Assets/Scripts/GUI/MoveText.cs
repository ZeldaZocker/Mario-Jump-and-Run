﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveText : MonoBehaviour {





	//Zum initialisieren
	void Start () {
		
	}
	
	//Wird einmal pro Frame aufgerufen
	void Update () {
		
	}
	
	
}