public class TerminalStrings
{
    public const string COMMAND_NOT_FOUND = "Command not found! type \"help\" for list of available commands!";
    public const string MULTIPLE_COMMAND_NAMES = "Multiple commands are defined with: ";
    public const string ARGUMENT_COUNT_MISSMATCH = "Method {0} needs {1} arguments, passed {2}";
}
