﻿namespace BeastConsole.GUI {
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    public class ConsoleGuiEventReceiver : MonoBehaviour {

    }
}