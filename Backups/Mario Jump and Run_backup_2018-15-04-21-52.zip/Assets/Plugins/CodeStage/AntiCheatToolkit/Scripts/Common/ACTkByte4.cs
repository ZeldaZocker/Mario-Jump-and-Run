﻿using System;

namespace CodeStage.AntiCheat.Common
{
	[Serializable]
	public struct ACTkByte4
	{
		public byte b1;
		public byte b2;
		public byte b3;
		public byte b4;
	}
}