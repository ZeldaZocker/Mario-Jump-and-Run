using UnityEngine;
using UnityEngine.SceneManagement;

public class SampleCommand
{
    [Command("debug", "Debugs a sample line in Unity Console")]
    public void SampleDebug()
    {
        Debug.Log("Ich bin ein Beispiel!");
    }

    [Command("reset", "Reloads the scene")]
    public void ResetScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}


