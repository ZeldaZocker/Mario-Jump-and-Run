public class TerminalStrings
{
    public const string COMMAND_NOT_FOUND = "Befehl nicht gefunden! Benutze \"help\" für eine Liste aller verfügbaren Befehle!";
    public const string MULTIPLE_COMMAND_NAMES = "Mehrere befehle wurden mir folgendem definiert: ";
    public const string ARGUMENT_COUNT_MISSMATCH = "Befehl {0} benötigt {1} Argumente. Angegebene Argumente: {2}";
}
