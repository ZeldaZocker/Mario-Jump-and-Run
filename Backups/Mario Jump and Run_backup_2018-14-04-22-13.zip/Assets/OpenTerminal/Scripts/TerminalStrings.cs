public class TerminalStrings
{
    public const string COMMAND_NOT_FOUND = "Befehl nicht gefunden! Benutze \"help\" um eine Liste der verf�gbaren Befehlen zu erhalten!";
    public const string MULTIPLE_COMMAND_NAMES = "Mehrere Befehle sind mit folgendem definiert: ";
    public const string ARGUMENT_COUNT_MISSMATCH = "Funktion {0} ben�tigt {1} Argumente. Angegebene Argumente: {2}";
}
