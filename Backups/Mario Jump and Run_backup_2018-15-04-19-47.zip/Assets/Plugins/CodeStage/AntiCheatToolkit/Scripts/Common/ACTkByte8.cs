﻿using System;

namespace CodeStage.AntiCheat.Common
{
	[Serializable]
	public struct ACTkByte8
	{
		public byte b1;
		public byte b2;
		public byte b3;
		public byte b4;
		public byte b5;
		public byte b6;
		public byte b7;
		public byte b8;
	}
}