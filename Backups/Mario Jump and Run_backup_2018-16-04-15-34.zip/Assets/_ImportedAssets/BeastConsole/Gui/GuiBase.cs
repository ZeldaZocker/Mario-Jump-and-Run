﻿namespace BeastConsole.GUI {

    using UnityEngine;

    public class GuiBase : MonoBehaviour {

    }
}