﻿using UnityEngine;

public class CharacterStats : MonoBehaviour
{

    public int maxHealt = 10;
    public int currentHealth { get; private set; }

    public Stat damage;
    public Stat armor;



    void Awake()
    {
        currentHealth = maxHealt;
    }

    public void TakenDamage(int damage)
    {
        damage -= armor.GetValue();
        damage = Mathf.Clamp(damage, 0, int.MaxValue);
        currentHealth -= damage;
        Debug.Log(transform.name + " takes " + damage + " damage.");

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public virtual void Die()
    {
        // Die in some way
        // This method is meant to be overwritten
        GameObject.FindWithTag("Player").GetComponent<PlayerMovement>().Respawn();
        Debug.Log(transform.name + " dies.");
    }

}